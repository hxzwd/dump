1.
	./sv
2.
	./cl localhost files/testfile.txt,0,10
	./cl localhost write
	./cl localhost abc
	./cl localhost @newline
	./cl localhost de
	./cl localhost @newline
	./cl localhost 5
	./cl localhost @newline
	./cl nowrite
